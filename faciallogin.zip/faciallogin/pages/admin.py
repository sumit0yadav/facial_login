from django.contrib import admin
from .models import Embeds,Profile


# Register your models here.
admin.site.register(Embeds)
admin.site.register(Profile)


